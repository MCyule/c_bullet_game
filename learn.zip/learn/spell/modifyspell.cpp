#include "modifyspell.h"
#include "spell/spell.h"

ModifySpell::ModifySpell(Spell *parent)
    : Spell{parent}
{}

void ModifySpell::apply(Spell* spell){

}
void ModifySpell::remove(Spell* spell){

}
