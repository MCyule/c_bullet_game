#include "projectileconfig.h"

ProjectileConfig::ProjectileConfig()
{


}
